// Intégration de Snipcart pour la boutique en ligne
document.addEventListener('DOMContentLoaded', function() {
  // Configuration de base de Snipcart
  const snipcartConfig = {
    publicApiKey: 'YOUR_PUBLIC_API_KEY', // À remplacer par votre clé API Snipcart
    defaultLang: 'fr',
    currency: 'EUR',
    templatesUrl: '/snipcart-templates.html',
    modalStyle: 'side',
  };
  
  // Initialisation de Snipcart
  window.SnipcartSettings = snipcartConfig;
  
  // Ajout des boutons d'achat aux produits
  function initializeProductButtons() {
    const addToCartButtons = document.querySelectorAll('.add-to-cart-button');
    
    addToCartButtons.forEach(button => {
      button.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Récupération des données du produit
        const productId = this.getAttribute('data-product-id');
        const productName = this.getAttribute('data-product-name');
        const productPrice = this.getAttribute('data-product-price');
        const productImage = this.getAttribute('data-product-image');
        const productUrl = window.location.href;
        
        // Ajout au panier via Snipcart
        window.Snipcart.api.cart.items.add({
          id: productId,
          name: productName,
          price: productPrice,
          url: productUrl,
          image: productImage
        });
      });
    });
  }
  
  // Initialisation des fonctionnalités de la boutique
  function initializeShop() {
    initializeProductButtons();
    
    // Mise à jour du compteur du panier
    function updateCartCount() {
      const cartCount = document.querySelector('.cart-count');
      if (cartCount) {
        window.Snipcart.store.subscribe(() => {
          const state = window.Snipcart.store.getState();
          cartCount.textContent = state.cart.items.count;
        });
      }
    }
    
    // Initialisation du compteur du panier après chargement de Snipcart
    document.addEventListener('snipcart.ready', function() {
      updateCartCount();
    });
  }
  
  // Chargement du script Snipcart
  function loadSnipcart() {
    const script = document.createElement('script');
    script.src = 'https://cdn.snipcart.com/themes/v3.2.2/default/snipcart.js';
    script.async = true;
    document.body.appendChild(script);
    
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = 'https://cdn.snipcart.com/themes/v3.2.2/default/snipcart.css';
    document.head.appendChild(link);
    
    // Ajout du div pour le panier Snipcart
    const snipcartDiv = document.createElement('div');
    snipcartDiv.hidden = true;
    snipcartDiv.id = 'snipcart';
    snipcartDiv.setAttribute('data-config-modal-style', 'side');
    snipcartDiv.setAttribute('data-api-key', snipcartConfig.publicApiKey);
    document.body.appendChild(snipcartDiv);
    
    // Initialisation de la boutique après chargement de Snipcart
    script.onload = function() {
      initializeShop();
    };
  }
  
  // Chargement de Snipcart
  loadSnipcart();
  
  // Gestion des variations de produits
  function handleProductVariations() {
    const variationSelects = document.querySelectorAll('.product-variation-select');
    
    variationSelects.forEach(select => {
      select.addEventListener('change', function() {
        const productContainer = this.closest('.product-container');
        const addToCartButton = productContainer.querySelector('.add-to-cart-button');
        const selectedOption = this.options[this.selectedIndex];
        
        // Mise à jour des attributs du bouton d'ajout au panier
        if (addToCartButton) {
          addToCartButton.setAttribute('data-product-id', selectedOption.getAttribute('data-variation-id'));
          addToCartButton.setAttribute('data-product-price', selectedOption.getAttribute('data-variation-price'));
          
          // Mise à jour du prix affiché
          const priceDisplay = productContainer.querySelector('.product-price');
          if (priceDisplay) {
            priceDisplay.textContent = `${selectedOption.getAttribute('data-variation-price')} €`;
          }
        }
      });
    });
  }
  
  // Initialisation des variations de produits
  handleProductVariations();
});
