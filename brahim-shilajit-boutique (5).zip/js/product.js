// product.js - Script pour la page produit
document.addEventListener('DOMContentLoaded', function() {
    // Gestion des miniatures produit
    const thumbnails = document.querySelectorAll('.thumbnail');
    const mainImage = document.getElementById('main-product-image');
    
    thumbnails.forEach(thumbnail => {
        thumbnail.addEventListener('click', function() {
            // Mise à jour de l'image principale
            const imageUrl = this.getAttribute('data-image');
            mainImage.src = imageUrl;
            
            // Mise à jour de la classe active
            thumbnails.forEach(item => item.classList.remove('active'));
            this.classList.add('active');
        });
    });
    
    // Gestion des onglets produit
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabPanels = document.querySelectorAll('.tab-panel');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Récupération de l'ID du panneau à afficher
            const tabId = this.getAttribute('data-tab');
            const targetPanel = document.getElementById(`${tabId}-panel`);
            
            // Mise à jour des classes actives
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabPanels.forEach(panel => panel.classList.remove('active'));
            
            this.classList.add('active');
            targetPanel.classList.add('active');
        });
    });
    
    // Gestion de la quantité
    const quantityInput = document.getElementById('product-quantity-input');
    const decreaseBtn = document.querySelector('.quantity-decrease');
    const increaseBtn = document.querySelector('.quantity-increase');
    
    if (decreaseBtn && increaseBtn && quantityInput) {
        decreaseBtn.addEventListener('click', function() {
            let value = parseInt(quantityInput.value);
            if (value > 1) {
                quantityInput.value = value - 1;
                updateAddToCartQuantity();
            }
        });
        
        increaseBtn.addEventListener('click', function() {
            let value = parseInt(quantityInput.value);
            if (value < 10) {
                quantityInput.value = value + 1;
                updateAddToCartQuantity();
            }
        });
        
        quantityInput.addEventListener('change', function() {
            let value = parseInt(this.value);
            if (value < 1) this.value = 1;
            if (value > 10) this.value = 10;
            updateAddToCartQuantity();
        });
    }
    
    // Mise à jour de la quantité pour le bouton d'ajout au panier
    function updateAddToCartQuantity() {
        const addToCartButton = document.querySelector('.add-to-cart-button');
        const buyNowButton = document.querySelector('.buy-now-button');
        const quantity = parseInt(quantityInput.value);
        
        if (addToCartButton) {
            addToCartButton.setAttribute('data-item-quantity', quantity);
        }
        
        if (buyNowButton) {
            buyNowButton.setAttribute('data-item-quantity', quantity);
        }
    }
    
    // Initialisation de la quantité
    updateAddToCartQuantity();
    
    // Gestion des variations de produit
    const variationSelect = document.getElementById('product-size');
    
    if (variationSelect) {
        variationSelect.addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            const variationId = selectedOption.getAttribute('data-variation-id');
            const variationPrice = selectedOption.getAttribute('data-variation-price');
            const addToCartButton = document.querySelector('.add-to-cart-button');
            const buyNowButton = document.querySelector('.buy-now-button');
            const priceDisplay = document.querySelector('.product-price');
            
            // Mise à jour du prix affiché
            if (priceDisplay) {
                priceDisplay.textContent = `${variationPrice} €`;
            }
            
            // Mise à jour des attributs du bouton d'ajout au panier
            if (addToCartButton) {
                addToCartButton.setAttribute('data-product-id', variationId);
                addToCartButton.setAttribute('data-product-price', variationPrice);
                
                // Mise à jour du nom du produit avec la variation
                const baseName = "Brahim Shilajit Premium";
                const variationName = selectedOption.textContent;
                addToCartButton.setAttribute('data-product-name', `${baseName} - ${variationName}`);
            }
            
            // Mise à jour des attributs du bouton d'achat immédiat
            if (buyNowButton) {
                buyNowButton.setAttribute('data-product-id', variationId);
                buyNowButton.setAttribute('data-product-price', variationPrice);
            }
        });
    }
    
    // Gestion du bouton d'achat immédiat
    const buyNowButton = document.querySelector('.buy-now-button');
    
    if (buyNowButton) {
        buyNowButton.addEventListener('click', function() {
            const addToCartButton = document.querySelector('.add-to-cart-button');
            
            // Simuler un clic sur le bouton d'ajout au panier
            if (addToCartButton) {
                addToCartButton.click();
            }
            
            // Rediriger vers le panier après un court délai
            setTimeout(function() {
                document.querySelector('.snipcart-checkout').click();
            }, 500);
        });
    }
    
    // Chargement des avis supplémentaires
    const loadMoreButton = document.querySelector('.load-more-button');
    
    if (loadMoreButton) {
        loadMoreButton.addEventListener('click', function() {
            // Dans une implémentation réelle, cette fonction chargerait plus d'avis depuis une API
            // Pour cette démo, nous allons simplement ajouter quelques avis statiques
            
            const reviewsList = document.querySelector('.reviews-list');
            const newReviews = `
                <div class="review-item">
                    <div class="review-header">
                        <div class="reviewer-info">
                            <div class="reviewer-name">Mohammed L.</div>
                            <div class="review-date">05/04/2025</div>
                        </div>
                        <div class="review-rating">
                            <span class="star">★</span>
                            <span class="star">★</span>
                            <span class="star">★</span>
                            <span class="star">★</span>
                            <span class="star">★</span>
                        </div>
                    </div>
                    <div class="review-title">Excellent pour la concentration</div>
                    <div class="review-content">
                        <p>Je suis entrepreneur et j'ai souvent besoin d'être concentré pendant de longues périodes. Ce produit m'a vraiment aidé à maintenir ma concentration et mon énergie tout au long de la journée, sans les effets secondaires du café.</p>
                    </div>
                    <div class="review-verified">✓ Achat vérifié</div>
                </div>
                
                <div class="review-item">
                    <div class="review-header">
                        <div class="reviewer-info">
                            <div class="reviewer-name">Samir B.</div>
                            <div class="review-date">22/03/2025</div>
                        </div>
                        <div class="review-rating">
                            <span class="star">★</span>
                            <span class="star">★</span>
                            <span class="star">★</span>
                            <span class="star">★</span>
                            <span class="star">★</span>
                        </div>
                    </div>
                    <div class="review-title">Livraison rapide, produit de qualité</div>
                    <div class="review-content">
                        <p>J'ai reçu ma commande très rapidement et le produit est exactement comme décrit. L'emballage est élégant et le Shilajit est d'excellente qualité. Je l'utilise depuis un mois et je constate déjà des améliorations dans mon énergie quotidienne.</p>
                    </div>
                    <div class="review-verified">✓ Achat vérifié</div>
                </div>
            `;
            
            // Insérer les nouveaux avis avant le bouton "Voir plus"
            const loadMoreReviews = document.querySelector('.load-more-reviews');
            loadMoreReviews.insertAdjacentHTML('beforebegin', newReviews);
            
            // Cacher le bouton après avoir chargé tous les avis
            loadMoreButton.style.display = 'none';
        });
    }
});
